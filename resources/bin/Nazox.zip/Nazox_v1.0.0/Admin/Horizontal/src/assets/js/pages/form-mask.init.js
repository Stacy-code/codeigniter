/*
Template Name: Nazox - Responsive Bootstrap 4 Admin Dashboard
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Form mask Js File
*/

$(document).ready(function(){
    $(".input-mask").inputmask();
});